let months = [
    {   
        month: 'Janeiro',
        color: 'amarelo',
        days: 31
    },
    { 
        month: 'Fevereiro',
        color: 'roxo',
        days: 28
    },
    { 
        month: 'Março',
        color: 'verde',
        days: 31
    },
    { 
        month: 'Abril',
        color: 'beje',
        days: 30
    },
    { 
        month: 'Maio',
        color: 'vermelho',
        days: 31
    },
    { 
        month: 'Junho',
        color: 'marron',
        days: 30
    },
    { 
        month: 'Julho',
        color: 'laranja',
        days: 31
    },
    { 
        month: 'Agosto',
        color: 'cinza',
        days: 31
    },
    { 
        month: 'Setembro',
        color: '',
        days: 30
    },
    { 
        month: 'Outubro',
        color: 'azul',
        days: 31
    },
    { 
        month: 'Novembro',
        color: 'rosa',
        days: 30
    },
    {
        month: 'Dezembro',
        color: 'branco',
        days: 31
    }
]

function getMonths(){
    return months
}

export default getMonths()