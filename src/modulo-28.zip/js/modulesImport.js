// import boostrap from 'bootstrap'
// import * as nomeQuaquer from './modulesExport'
import Cachorro from './classes'

const cachorro = new Cachorro('cachorro')
cachorro.falar()
cachorro.comer()
cachorro.dormir()